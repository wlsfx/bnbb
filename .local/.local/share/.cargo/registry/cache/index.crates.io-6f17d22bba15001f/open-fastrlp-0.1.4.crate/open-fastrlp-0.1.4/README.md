# RLP encoder decoder crate

forked from erlier Apache licenced fastrlp crate, before it changed licence to GPL 