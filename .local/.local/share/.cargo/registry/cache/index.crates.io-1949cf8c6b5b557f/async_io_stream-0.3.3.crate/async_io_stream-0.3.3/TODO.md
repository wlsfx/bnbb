# TODO

- examples
- setup issue labels on GH
- test map_pharos
- check codekov
