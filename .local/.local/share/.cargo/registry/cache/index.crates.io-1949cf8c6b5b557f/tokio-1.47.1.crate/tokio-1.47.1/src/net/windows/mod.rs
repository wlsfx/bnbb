//! Windows specific network types.

pub mod named_pipe;
