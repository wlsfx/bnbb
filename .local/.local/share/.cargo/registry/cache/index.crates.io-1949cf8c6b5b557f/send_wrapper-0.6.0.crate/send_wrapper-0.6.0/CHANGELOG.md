# Changelog

## [0.5.0] - 2020-10-14
- add transparent wrapping of `Future` and `Stream` types via new cargo feature `futures`

## [0.4.0] - 2019-11-18
- add `Clone` and `Debug` implementations

## [0.3.0] - 2019-10-16
- implement `Sync` marker trait

## [0.2.0] - 2017-10-04
- add `take()` method

## [0.1.0] - 2017-09-07
- initial release
