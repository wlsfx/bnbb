# Changelog

### Unreleased

### 0.4.1

- Add `geth-compat` feature that makes keystore creation/handling
  compatible with geth [#12](https://github.com/roynalnaruto/eth-keystore-rs/pull/12)

### 0.4.0

- Add support for custom naming of generated keystore files [#9](https://github.com/roynalnaruto/eth-keystore-rs/pull/9)
