// see comment in module above this in `link_mem_intrinsics`
#[inline(never)]
#[cfg_attr(wasm_bindgen_unstable_test_coverage, coverage(off))]
pub fn link_intrinsics() {}
