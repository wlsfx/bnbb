# RLP

Recursive-length-prefix encoding, decoding, and compression in Rust.

## License

Unlike most parts of Parity, which fall under the GPLv3, this package is dual-licensed under MIT/Apache2 at the user's choice.
Find the associated license files in this directory as `LICENSE-MIT` and `LICENSE-APACHE2` respectively.
