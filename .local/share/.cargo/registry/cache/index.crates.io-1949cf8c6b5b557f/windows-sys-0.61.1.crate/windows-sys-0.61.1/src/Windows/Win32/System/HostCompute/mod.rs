pub type HCS_CALLBACK = *mut core::ffi::c_void;
