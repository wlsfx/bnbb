//! Types.
//!
//! This module is a reexport of the `postgres_types` crate.

#[doc(inline)]
pub use postgres_types::*;
