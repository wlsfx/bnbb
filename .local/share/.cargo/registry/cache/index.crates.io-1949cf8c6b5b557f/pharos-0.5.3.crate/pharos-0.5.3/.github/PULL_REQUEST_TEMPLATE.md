<!--- When contributing all contributions should branch off the -->
<!--- dev branch as master is only used for releases. -->

<!--- Check CONTRIBUTING.md for more information-->

<!--- Please describe the changes in the PR and the motivation below -->
