//! # json
//!
//! ```rust,ignore
#![doc = include_str!("../../examples/json/parser_dispatch.rs")]
//! ```
