# 0.0.2

- Add new `rustc-dep-of-std` feature to allow building `libproc-macro`

# 0.0.1

- Add `EscapeError`, `MixedUnit` and `Mode` enums
- Add `byte_from_char`, `unescape_byte`, `unescape_char`, `unescape_mixed` and `unescape_unicode` functions
