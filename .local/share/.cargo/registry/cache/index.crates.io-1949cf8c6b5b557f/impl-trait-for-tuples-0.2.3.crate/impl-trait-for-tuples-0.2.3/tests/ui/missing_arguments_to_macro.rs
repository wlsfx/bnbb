#[impl_trait_for_tuples::impl_for_tuples()]
trait Test {}

fn main() {}
