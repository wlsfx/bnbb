#[impl_trait_for_tuples::impl_for_tuples(5, 2)]
trait Test {}

fn main() {}
