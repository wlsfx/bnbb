#[impl_trait_for_tuples::impl_for_tuples(1)]
trait Test {
    fn test() -> u32;
}

fn main() {}
