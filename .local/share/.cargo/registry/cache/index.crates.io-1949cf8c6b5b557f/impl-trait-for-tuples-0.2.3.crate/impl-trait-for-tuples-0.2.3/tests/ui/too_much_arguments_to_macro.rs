#[impl_trait_for_tuples::impl_for_tuples(1, 2, 3)]
trait Test {}

fn main() {}
