use auto_impl::auto_impl;

#[auto_impl(&)]
trait MyTrait<T,> {}

fn main() { }
