use auto_impl::auto_impl;


#[auto_impl(&, &mut)]
type Baz = String;


fn main() {}
