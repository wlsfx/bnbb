# ethers-contract-abigen

Code generation for type-safe bindings to Ethereum smart contracts.

This code generator was adapted from the original [ethcontract-rs repository by Gnosis](https://github.com/gnosis/ethcontract-rs/tree/master/generate).

For more information, please refer to the [book](https://gakonst.com/ethers-rs).
