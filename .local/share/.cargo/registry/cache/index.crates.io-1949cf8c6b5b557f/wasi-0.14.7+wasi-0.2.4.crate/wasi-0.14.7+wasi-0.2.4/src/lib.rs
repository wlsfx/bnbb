#![no_std]
pub use wasip2::*;
