# unicode-properties

[![Build Status](https://github.com/unicode-rs/unicode-properties/workflows/Tests/badge.svg)](https://github.com/unicode-rs/unicode-properties/actions)
[![Current Version](https://img.shields.io/crates/v/unicode-properties.svg)](https://crates.io/crates/unicode-properties)
[![License: MIT/Apache-2.0](https://img.shields.io/crates/l/unicode-properties.svg)](#license)
