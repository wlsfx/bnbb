# Changelog

The format is based on [Keep a Changelog].

[Keep a Changelog]: http://keepachangelog.com/en/1.0.0/

## [Unreleased]
### Breaking
- Updated `rlp` to 0.5. [#463](https://github.com/paritytech/parity-common/pull/463)
