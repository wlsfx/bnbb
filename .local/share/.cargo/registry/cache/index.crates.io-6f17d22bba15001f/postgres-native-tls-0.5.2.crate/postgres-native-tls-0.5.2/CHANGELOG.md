# Change Log

## v0.5.2 - 2025-09-25

### Changed

* Updated repository links to use `rust-postgres` organization.
* Upgraded to Rust 2021 edition.

## v0.5.1 - 2025-02-02

### Added

* Added `set_postgresql_alpn`.

## v0.5.0 - 2020-12-25

### Changed

* Upgraded to `tokio-postgres` 0.7.

## v0.4.0 - 2020-10-17

### Changed

* Upgraded to `tokio-postgres` 0.6.

## v0.3.0 - 2019-12-23

### Changed

* Upgraded to `tokio-postgres` 0.5.

## v0.3.0-alpha.2 - 2019-11-27

### Changed

* Upgraded to `tokio-postgres` v0.5.0-alpha.2.

## v0.3.0-alpha.1 - 2019-10-14

### Changed

* Updated to `tokio-postgres` v0.5.0-alpha.1.

## v0.2.0-rc.1 - 2019-06-29

### Changed

* Updated to `tokio-postgres` v0.4.0-rc.
