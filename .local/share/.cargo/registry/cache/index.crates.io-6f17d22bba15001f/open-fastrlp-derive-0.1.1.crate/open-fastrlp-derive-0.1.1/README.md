# RLP derive crate

forked from erlier Apache licenced fastrlp-derive crate, before it changed licence to GPL.