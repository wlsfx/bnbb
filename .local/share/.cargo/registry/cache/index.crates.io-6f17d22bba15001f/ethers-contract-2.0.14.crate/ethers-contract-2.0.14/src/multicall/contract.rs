#![allow(missing_docs)]
use ethers_contract_derive::abigen;

abigen!(Multicall3, "src/multicall/multicall_abi.json");
