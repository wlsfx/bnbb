# ethers-contract-derive

Proc macros for type-safe bindings generation to Ethereum smart contracts.

Adapted from the original [ethcontract-rs repository by Gnosis](https://github.com/gnosis/ethcontract-rs/tree/master/derive).

For more information, please refer to the [book](https://gakonst.com/ethers-rs).
